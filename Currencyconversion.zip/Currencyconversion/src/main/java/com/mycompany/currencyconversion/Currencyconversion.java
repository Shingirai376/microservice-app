/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.currencyconversion;

/**
 *
 * @author snjitima
 */
import java.util.Scanner;

public class Currencyconversion {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Currency Converter: USD to ZWL");
        System.out.println("Enter the amount in USD:");
        double usdAmount = scanner.nextDouble();

        // Conversion rates
        double usdToZwlRate = 40000; // 1 USD = 40000 ZWL
        double zwlToUsdRate = 1 / usdToZwlRate; // 1 ZWL = 0.000025 USD
        
        // Convert USD to ZWL
        double zwlAmount = usdAmount * usdToZwlRate;
        System.out.println(usdAmount + " USD is equal to " + zwlAmount + " ZWL");

        // Convert ZWL to USD
        System.out.println("Enter the amount in ZWL:");
        double zwlAmountInput = scanner.nextDouble();
        double usdAmountConverted = zwlAmountInput * zwlToUsdRate;
        System.out.println(zwlAmountInput + " ZWL is equal to " + usdAmountConverted + " USD");

        //
        System.out.println("Currency Converter: ZIG to Bond");
        System.out.println("Enter the amount in ZIG:");
        double zigAmountInput = scanner.nextDouble();

        // Conversion rates 2
        double zigToZwlRate = 2000; //1 ZIG = 2000 ZWL
        double zwlToZigRate = 1 / zigToZwlRate; // 1 ZWL = 0.0005 ZIG
        
        // Convert ZIG to ZWL
        double zigAmount = zwlAmount * zwlToZigRate;
        System.out.println(zigAmountInput + " ZIG is equal to " + zigAmount + " ZWL");
       
        scanner.close();
    }
}

